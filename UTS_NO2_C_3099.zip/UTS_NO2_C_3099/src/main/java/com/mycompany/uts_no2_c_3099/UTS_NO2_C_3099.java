/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no2_c_3099;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author lenovo
 */
public class UTS_NO2_C_3099 {

    public static void main(String[] args) {
        SalariedEmployee_3099 se_3099 = new SalariedEmployee_3099();
        CommissionEmployee_3099 ce_3099 = new CommissionEmployee_3099();
        ProjectPlanner_3099 pp_3099 = new ProjectPlanner_3099();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));        
        try{
            System.out.println("Data Pegawai");
            System.out.print("Nama: ");
            se_3099.Nama_3099 = br.readLine();
            System.out.print("NIP: ");
            se_3099.NIP_3099 = br.readLine();
            System.out.print("Gaji Pokok: ");
            se_3099.GajiPokok_3099 = Float.parseFloat(br.readLine());
            se_3099.TampilData_3099();
            
            System.out.print("Nama: ");
            ce_3099.Nama_3099 = br.readLine();
            System.out.print("NIP: ");
            ce_3099.NIP_3099 = br.readLine();
            System.out.print("GajiPokok: ");
            ce_3099.GajiPokok_3099 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            ce_3099.Komisi_3099 = Float.parseFloat(br.readLine());
            System.out.print("Total Penjualan: ");
            ce_3099.TotalPenjualan_3099 = Float.parseFloat(br.readLine());
            ce_3099.TotalGaji_3099();
            ce_3099.TampilData_3099();
            
            System.out.print("Nama: ");
            pp_3099.Nama_3099 = br.readLine();
            System.out.print("NIP: ");
            pp_3099.NIP_3099 = br.readLine();
            System.out.print("Gaji Pokok: ");
            pp_3099.GajiPokok_3099 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            pp_3099.Komisi_3099 = Float.parseFloat(br.readLine());
            System.out.print("Total Hasil Proyek: ");
            pp_3099.TotalHslProyek_3099 = Float.parseFloat(br.readLine());
            pp_3099.TotalGaji_3099();
            pp_3099.TampilData_3099();
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
}
