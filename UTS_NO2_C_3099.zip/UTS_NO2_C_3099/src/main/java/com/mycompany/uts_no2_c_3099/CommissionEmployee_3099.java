/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3099;

/**
 *
 * @author lenovo
 */
public class CommissionEmployee_3099 extends Employess_3099{
    public float Komisi_3099;
    public float TotalPenjualan_3099;
    public float Totalgaji_3099;
    
    public CommissionEmployee_3099(){
        
    }
    
    public float TotalGaji_3099(){
        Totalgaji_3099 = GajiPokok_3099 + (Komisi_3099 * TotalPenjualan_3099);
        return Totalgaji_3099;
    }
    
    public void TampilData_3099(){
        System.out.println("Commission Employee");
        Tampil_3099();
        System.out.println("Total Gaji: " + Totalgaji_3099);
    }
}
