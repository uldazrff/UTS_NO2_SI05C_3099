/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3099;

/**
 *
 * @author badnoby
 */
public class SalariedEmployee_3099 extends Employess_3099 {
    public SalariedEmployee_3099(){
        
    }
    
    public void TampilData_3099(){
        System.out.println("Salaried Employee");
        Tampil_3099();
        System.out.println("Total Gaji: " + GajiPokok_3099);
    }
}
